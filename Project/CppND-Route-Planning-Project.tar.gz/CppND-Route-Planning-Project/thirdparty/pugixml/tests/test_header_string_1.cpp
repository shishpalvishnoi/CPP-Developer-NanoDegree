// Tests compatibility with string
#include "../src/pugixml.hpp"
#include <string>
